/**
 * Created by tgdflto1 on 08/01/17.
 */
$(document).ready(function(){
    $('.datetimepicker').datetimepicker({
        format: 'd.m.Y H:i',
    });
});