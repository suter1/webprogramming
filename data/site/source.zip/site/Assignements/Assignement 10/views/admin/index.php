<?php require_once("views/default/default_header.php"); ?>


    <section class="section">
		<div>
            <a href="/user">Show Users</a><br>
            <a href="/special_offer">Show Special Offers</a><br>
		</div>
	</section>
<?php require_once("views/default/footer.php") ?>