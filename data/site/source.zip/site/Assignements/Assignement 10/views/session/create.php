<?php require_once("views/default/header.php") ?>
<?php require_once("views/default/navigation.php") ?>
    <section class="section">
        <article class="OptSize">
            <p>Bildgrössenauswahl</p>
            <article class="MetaData">"Meta data"</article>
        </article>
    </section>
<?php require_once("views/default/footer.php") ?>