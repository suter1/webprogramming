# TODO List

Was | Schätzung | Status
--- | --- | ---
Admin Page: Verkäufe,  Bilder eines Users Anzeigen inkl. gelöschte, Liste der User inkl. Suchfunktion, Checkbox für gelöschte | easy |
Kaufen inkl. Rückmeldung und Mail | ev. tricky | done
Bilder löschen (owner & admin, nur flag in db) inkl. Rückmeldung | easy |
User löschen (admin & owner, nur flag in db) + Rückmeldung | easy | done
Aktionen erstellen (admin) + Rückmeldung | easy |
Bestellverlauf + Geldkonto pro User | tricky |
Assignements (Admin-Page & Checkout) | Prio 1 |
Bild Kauf & download in gekaufter Grösse | not so easy | done
Random Tags anzeigen anstatt statische | easy |
Admin button für Adminpage im Header | done |
Register: Mail Validierung | not so easy | done
Meta-Daten laden & editieren | easy | done
Wasserzeichen | easy | done
Input validation + Meldungen: Register, File upload | easy| done