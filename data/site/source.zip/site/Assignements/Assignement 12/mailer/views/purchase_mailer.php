<!DOCTYPE html>
	<head>

	</head>
	<body>
		<div style="font: "Helvetica", Arial, sans-serif">
			<span>Your purchase was successful, you can download the pictures under the following link:
                <a href="<% 'download_link' %>"><% 'download_link' %></a></span>
		</div>
	</body>
</html>