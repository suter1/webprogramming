<!DOCTYPE html>
	<head>

	</head>
	<body>
		<div style="font: "Helvetica", Arial, sans-serif">
			<span>Please activate your account with the followin link: <a href="<% 'activation_link' %>"><% 'activation_link' %></a></span>
		</div>
	</body>
</html>