<?php require_once("views/default/default_header.php"); ?>

<section class="section images">
<h4><?php echo "<a href='/order/". $options['order_id'] ."?download'>Download</a>"; ?></h4>
</section>
<?php require_once("views/default/footer.php") ?>
