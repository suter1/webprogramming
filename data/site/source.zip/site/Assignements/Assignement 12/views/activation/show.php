<?php require_once("views/default/default_header.php"); ?>

<?php require_once 'autoload.php'; ?>
	<section class="section">
		<div>
			<span><?php echo $options['message'] ?></span>
		</div>
	</section>
<?php require_once("views/default/footer.php") ?>