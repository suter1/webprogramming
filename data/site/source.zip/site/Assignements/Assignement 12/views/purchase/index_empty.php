<ul class="basket-list">
	Please login to buy pictures
	<input type='hidden' id='basket_count' name='basket_count' value='0'>
</ul>