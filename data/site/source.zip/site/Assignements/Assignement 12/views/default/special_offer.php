<aside class='equalHW eq' style="max-width: 300px; background-color: #E6E6FA; border-radius: 4px;">
	<div id="special_offer" class="">

	</div>
</aside>