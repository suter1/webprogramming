                </div> <!-- content -->
            <?php require_once("views/default/special_offer.php"); ?>
            </div> <!-- container -->
                <span style="font-size: 0.7em">Copyright 2017 <a href="/impressum">Impressum</a></span>
        </div>
    </body>
</html>