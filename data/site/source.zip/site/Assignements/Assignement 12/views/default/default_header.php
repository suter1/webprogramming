<?php
/**
 * Created by PhpStorm.
 * User: tgdflto1
 * Date: 04/01/17
 * Time: 09:36
 */
require_once("views/default/header.php");
require_once("views/default/navigation.php");
require_once("views/default/flash.php");