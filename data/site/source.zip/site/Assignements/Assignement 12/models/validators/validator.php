<?php
/**
 * Created by PhpStorm.
 * User: maestro7
 * Date: 15.11.2016
 * Time: 20:12
 */

abstract class Validator {

	public abstract function isValid();
}